import sympy as sp

def det(a11,a12,a13,a21,a22,a23,a31,a32,a33):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return round(A.det(),2)

def adjugate(a11:int,a12:int,a13:int,a21:int,a22:int,a23:int,a31:int,a32:int,a33:int):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return A.adjugate()

def eigenvals(a11:int,a12:int,a13:int,a21:int,a22:int,a23:int,a31:int,a32:int,a33:int):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return A.eigenvals()

def eigenvects(a11:int,a12:int,a13:int,a21:int,a22:int,a23:int,a31:int,a32:int,a33:int):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return A.eigenvects()

def diagonalize(a11:int,a12:int,a13:int,a21:int,a22:int,a23:int,a31:int,a32:int,a33:int):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return A.diagonalize()
