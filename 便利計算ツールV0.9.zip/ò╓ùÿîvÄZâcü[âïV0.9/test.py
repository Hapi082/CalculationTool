import sympy as sp

x,y,z = sp.symbols("x,y,z")

def invers(a11,a12,a13,a21,a22,a23,a31,a32,a33):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return A.inv()

def diagonalize(a11:int,a12:int,a13:int,a21:int,a22:int,a23:int,a31:int,a32:int,a33:int):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return A.diagonalize()

P = sp.Matrix([[-1,-1,1],[1,0,1],[0,1,1]])
P_1 = P.inv()
A = sp.Matrix([[1,0,0],[0,1,0],[0,0,4]])
A = A**5

vect = sp.Matrix([[1],[1],[1]])

PA = P*A
PA_1 = PA * P_1
print(PA_1 * vect)

print(5 ** (1/2))