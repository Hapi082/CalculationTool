from flask import Flask,render_template,request
from calculation import det,adjugate,eigenvals,eigenvects,diagonalize

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route("/page_det")
def page_det():
    return render_template("page_det.html")

@app.route("/page_adjugate")
def page_adjugate():
    return render_template("page_adjugate.html")

@app.route("/page_eigenvals")
def page_eigenvals():
    return render_template("page_eigenvals.html")

@app.route("/page_eigenvects")
def page_eigenvects():
    return render_template("page_eigenvects.html")

@app.route("/page_diagonalize")
def page_diagonalize():
    return render_template("page_diagonalize.html")

@app.route("/det", methods=["POST"])
def caluclate_det():
    if request.method == "POST":
        a11 = int(request.form["a11"])
        a12 = int(request.form["a12"])
        a13 = int(request.form["a13"])
        a21 = int(request.form["a21"])
        a22 = int(request.form["a22"])
        a23 = int(request.form["a23"])
        a31 = int(request.form["a31"])
        a32 = int(request.form["a32"])
        a33 = int(request.form["a33"])
        result = det(a11,a12,a13,a21,a22,a23,a31,a32,a33)
        return render_template("page_det.html",result = result)

@app.route("/adjugate", methods=["POST"])
def caluclate_adjugate():
    if request.method == "POST":
        a11 = int(request.form["a11"])
        a12 = int(request.form["a12"])
        a13 = int(request.form["a13"])
        a21 = int(request.form["a21"])
        a22 = int(request.form["a22"])
        a23 = int(request.form["a23"])
        a31 = int(request.form["a31"])
        a32 = int(request.form["a32"])
        a33 = int(request.form["a33"])
        result = adjugate(a11,a12,a13,a21,a22,a23,a31,a32,a33)
        result11,result12,result13,result21,result22,result23,result31,result32,result33 = result[0,0],result[0,1],result[0,2],result[1,0],result[1,1],result[1,2],result[2,0],result[2,1],result[2,2]

        return render_template("page_adjugate.html",result11=result11,result12=result12,result13=result13,
                                                    result21=result21,result22=result22,result23=result23,
                                                    result31=result31,result32=result32,result33=result33)
    
@app.route("/eigenvals", methods=["POST"])
def caluclate_eigenvals():
    if request.method == "POST":
        a11 = int(request.form["a11"])
        a12 = int(request.form["a12"])
        a13 = int(request.form["a13"])
        a21 = int(request.form["a21"])
        a22 = int(request.form["a22"])
        a23 = int(request.form["a23"])
        a31 = int(request.form["a31"])
        a32 = int(request.form["a32"])
        a33 = int(request.form["a33"])
        result = eigenvals(a11,a12,a13,a21,a22,a23,a31,a32,a33)
        return render_template("page_eigenvals.html",result = result)
    
@app.route("/eigenvects", methods=["POST"])
def caluclate_eigenvects():
    if request.method == "POST":
        a11 = int(request.form["a11"])
        a12 = int(request.form["a12"])
        a13 = int(request.form["a13"])
        a21 = int(request.form["a21"])
        a22 = int(request.form["a22"])
        a23 = int(request.form["a23"])
        a31 = int(request.form["a31"])
        a32 = int(request.form["a32"])
        a33 = int(request.form["a33"])
        result = eigenvects(a11,a12,a13,a21,a22,a23,a31,a32,a33)
        return render_template("page_eigenvects.html",result = result)
    
@app.route("/diagonalize", methods=["POST"])
def caluclate_diagonalize():
    if request.method == "POST":
        a11 = int(request.form["a11"])
        a12 = int(request.form["a12"])
        a13 = int(request.form["a13"])
        a21 = int(request.form["a21"])
        a22 = int(request.form["a22"])
        a23 = int(request.form["a23"])
        a31 = int(request.form["a31"])
        a32 = int(request.form["a32"])
        a33 = int(request.form["a33"])
        result1 = diagonalize(a11,a12,a13,a21,a22,a23,a31,a32,a33)
        return render_template("page_diagonalize.html",result = result1)
    

if __name__=="__main__":
    app.run()
