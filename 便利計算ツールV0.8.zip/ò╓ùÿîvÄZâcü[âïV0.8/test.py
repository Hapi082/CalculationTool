import sympy as sp

x,y,z = sp.symbols("x,y,z")

X = sp.expand(((x-2)**2) -4)
X_solve = sp.solve(X,"x")
print(X_solve)