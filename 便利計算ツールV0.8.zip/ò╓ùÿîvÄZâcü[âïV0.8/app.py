from flask import Flask,render_template,request
from calculation import det,adjugate

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route("/page_det")
def page_det():
    return render_template("page_det.html")

@app.route("/page_adjugate")
def page_adjugate():
    return render_template("page_adjugate.html")

@app.route("/det", methods=["POST"])
def caluclate_det():
    if request.method == "POST":
        a11 = float(request.form["a11"])
        a12 = float(request.form["a12"])
        a13 = float(request.form["a13"])
        a21 = float(request.form["a21"])
        a22 = float(request.form["a22"])
        a23 = float(request.form["a23"])
        a31 = float(request.form["a31"])
        a32 = float(request.form["a32"])
        a33 = float(request.form["a33"])
        result = det(a11,a12,a13,a21,a22,a23,a31,a32,a33),
        return render_template("page_det.html",result = result)

@app.route("/adjugate", methods=["POST"])
def caluclate_adjugate():
    if request.method == "POST":
        a11 = float(request.form["a11"])
        a12 = float(request.form["a12"])
        a13 = float(request.form["a13"])
        a21 = float(request.form["a21"])
        a22 = float(request.form["a22"])
        a23 = float(request.form["a23"])
        a31 = float(request.form["a31"])
        a32 = float(request.form["a32"])
        a33 = float(request.form["a33"])
        result = adjugate(a11,a12,a13,a21,a22,a23,a31,a32,a33),
        return render_template("page_adjugate.html",result = result)

if __name__=="__main__":
    app.run()
