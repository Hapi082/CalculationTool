import math,random
import sympy as sp

def det(a11,a12,a13,a21,a22,a23,a31,a32,a33):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return round(A.det(),2)

def adjugate(a11,a12,a13,a21,a22,a23,a31,a32,a33):
    A = sp.Matrix([
        [a11,a12,a13],
        [a21,a22,a23],
        [a31,a32,a33]
    ])
    return A.adjugate()


